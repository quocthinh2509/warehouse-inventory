from django.apps import AppConfig


class ErpThe20Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'erp_the20'
