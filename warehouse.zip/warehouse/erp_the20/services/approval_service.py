def notify_approval_created(obj_type: str, obj_id: int):
    # TODO: đẩy vào Notification (email/lark/in-app)
    pass
