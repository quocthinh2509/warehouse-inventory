import math
from dataclasses import dataclass
from datetime import datetime, timedelta
from django.utils import timezone
from django.core.exceptions import ValidationError
from django.db import transaction
from erp_the20.models import AttendanceEvent, AttendanceSummary, Worksite, ShiftInstance
from erp_the20.selectors.attendance_selector import get_last_event, get_summary
from erp_the20.selectors.shift_selector import instances_around, instance_window_with_grace, planned_minutes

# --------- Geo helpers ---------

def _haversine(lat1, lon1, lat2, lon2):
    R = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlmb = math.radians(lon2 - lon1)
    a = (math.sin(dphi/2)**2) + math.cos(p1)*math.cos(p2)*(math.sin(dlmb/2)**2)
    return 2*R*math.asin(math.sqrt(a))


def validate_geofence(worksite: Worksite | None, lat, lng, accuracy_m):
    if not worksite or lat is None or lng is None:
        return None, None  # allow, unknown
    # treat too-poor accuracy as soft warning; you can hard fail if desired
    try:
        dist = _haversine(lat, lng, worksite.lat, worksite.lng)
    except Exception:
        return None, None
    return worksite, dist


# --------- Shift matching ---------

@dataclass
class MatchConfig:
    checkin_open_grace_min: int
    checkout_grace_min: int


def _best_instance_for_ts(ts, *, mode: str, prefer_ids: set[int] | None = None) -> ShiftInstance | None:
    """Pick the most plausible ShiftInstance for this timestamp within grace windows."""
    prefer_ids = prefer_ids or set()
    cands = []
    for inst in instances_around(ts):
        ws = inst.worksite or inst.template.default_worksite
        open_grace = (ws.checkin_open_grace_min if ws else 10)
        out_grace  = (ws.checkout_grace_min if ws else 10)
        start, end, start_g, end_g = instance_window_with_grace(
            inst, checkin_open_grace_min=open_grace, checkout_grace_min=out_grace
        )
        if start_g <= ts <= end_g:
            score = 0
            if mode == "in":
                score = abs((ts - start).total_seconds())
            else:
                score = abs((end - ts).total_seconds())
            priority = 0 if inst.id in prefer_ids else 1
            cands.append((priority, score, inst))
    if not cands:
        return None
    cands.sort(key=lambda x: (x[0], x[1]))
    return cands[0][2]


# --------- Public APIs ---------

@transaction.atomic
def add_check_in(*, employee, ts, lat=None, lng=None, accuracy_m=None, source="web", shift_instance_id: int | None = None, worksite_id: int | None = None):
    inst = None
    if shift_instance_id:
        inst = ShiftInstance.objects.filter(id=shift_instance_id).select_related("worksite", "template").first()
    prefer_ids = {inst.id} if inst else set()

    if not inst:
        inst = _best_instance_for_ts(ts, mode="in", prefer_ids=prefer_ids)

    ws = None
    if worksite_id:
        ws = Worksite.objects.filter(id=worksite_id).first()
    elif inst and inst.worksite:
        ws = inst.worksite
    elif inst and inst.template.default_worksite:
        ws = inst.template.default_worksite

    detected_ws, dist = validate_geofence(ws, lat, lng, accuracy_m)

    ev = AttendanceEvent.objects.create(
        employee=employee,
        shift_instance=inst,
        event_type="check_in",
        ts=ts,
        lat=lat,
        lng=lng,
        accuracy_m=accuracy_m,
        source=source,
        worksite_detected=detected_ws,
        distance_to_worksite_m=dist,
        raw_payload=None,
        is_valid=True  # you can toggle according to business rules
    )
    _ensure_summary(employee.id, ts.date())
    return ev


@transaction.atomic
def add_check_out(*, employee, ts, lat=None, lng=None, accuracy_m=None, source="web", shift_instance_id: int | None = None, worksite_id: int | None = None):
    inst = None
    if shift_instance_id:
        inst = ShiftInstance.objects.filter(id=shift_instance_id).select_related("worksite", "template").first()
    prefer_ids = {inst.id} if inst else set()

    if not inst:
        inst = _best_instance_for_ts(ts, mode="out", prefer_ids=prefer_ids)

    ws = None
    if worksite_id:
        ws = Worksite.objects.filter(id=worksite_id).first()
    elif inst and inst.worksite:
        ws = inst.worksite
    elif inst and inst.template.default_worksite:
        ws = inst.template.default_worksite

    detected_ws, dist = validate_geofence(ws, lat, lng, accuracy_m)

    ev = AttendanceEvent.objects.create(
        employee=employee,
        shift_instance=inst,
        event_type="check_out",
        ts=ts,
        lat=lat,
        lng=lng,
        accuracy_m=accuracy_m,
        source=source,
        worksite_detected=detected_ws,
        distance_to_worksite_m=dist,
        raw_payload=None,
        is_valid=True
    )
    _rollup_summary(employee.id, ts.date())
    return ev


def _ensure_summary(employee_id: int, date):
    if not get_summary(employee_id, date):
        AttendanceSummary.objects.create(employee_id=employee_id, date=date)


def _rollup_summary(employee_id: int, date):
    """Aggregate ALL events that fall on this date (and neighbor for overnight) into the daily summary."""
    tz = timezone.get_current_timezone()
    d0 = datetime.combine(date, datetime.min.time())
    d1 = datetime.combine(date, datetime.max.time())
    d0 = timezone.make_aware(d0, tz)
    d1 = timezone.make_aware(d1, tz)

    # pull events on date; simple pairing in order
    events = list(
        AttendanceEvent.objects.filter(employee_id=employee_id, ts__date=date).order_by("ts")
    )

    # Pair in/out
    total = 0
    start = None
    first_in = None
    last_out = None
    for ev in events:
        if ev.event_type == "check_in":
            start = ev.ts
            if first_in is None:
                first_in = ev.ts
        elif ev.event_type == "check_out" and start:
            total += int((ev.ts - start).total_seconds() // 60)
            last_out = ev.ts
            start = None

    # Planned minutes = sum of planned of instances the employee is scheduled (optional)
    # If you don't enforce assignment, you may compute plan from all instances on that date.
    planned = 0
    # if you have Assignment/Registration use their instances; else, skip or compute from all instances.
    # planned = sum(planned_minutes(inst) for inst in instances_for_employee_on_date(employee_id, date))

    late = early = ot = 0
    # If you want lateness/early/OT: you need mapping to the instance windows. This minimal rollup focuses on worked minutes.

    summary = get_summary(employee_id, date)
    if not summary:
        summary = AttendanceSummary.objects.create(employee_id=employee_id, date=date)

    summary.planned_minutes = planned
    summary.worked_minutes = total
    # Keep existing status unless present
    if total > 0 and summary.status not in ("leave", "holiday"):
        summary.status = "present"
    summary.late_minutes = late
    summary.early_leave_minutes = early
    summary.overtime_minutes = ot
    summary.save()