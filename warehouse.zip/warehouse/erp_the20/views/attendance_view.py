from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from erp_the20.models import Employee, Worksite, ShiftInstance, AttendanceSummary
from erp_the20.serializers.attendance_serializer import AttendanceCheckSerializer, AttendanceEventSerializer, AttendanceSummarySerializer
from erp_the20.services.attendance_service import add_check_in, add_check_out
from .utils import (
    extend_schema, extend_schema_view, OpenApiExample, OpenApiResponse,
    q_int, q_date, std_errors, ErrorSerializer
)


# --- Check In ---
@extend_schema_view(
    post=extend_schema(
        tags=["Attendance"],
        summary="Check in",
        description=(
            "Ghi nhận sự kiện check-in với toạ độ, độ chính xác và tùy chọn shift/worksite.\n"
            "Validate trùng lặp và độ chính xác nên trả về 400 (docs dùng Error schema)."
        ),
        request=AttendanceCheckSerializer,
        responses={
            201: OpenApiResponse(AttendanceEventSerializer, description="Tạo sự kiện check-in"),
            **std_errors()
        },
        examples=[
            OpenApiExample(
                "Body mẫu",
                request_only=True,
                value={
                    "employee": 1,
                    "ts": "2025-09-18T09:00:00Z",
                    "lat": 10.77,
                    "lng": 106.69,
                    "accuracy_m": 18,
                    "worksite": 3,
                    "shift_instance": 12,
                    "source": "web",
                },
            ),
        ],
    )
)
class CheckInView(APIView):
    def post(self, request):
        ser = AttendanceCheckSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        v = ser.validated_data
        emp = Employee.objects.get(id=v["employee"])
        ws = Worksite.objects.filter(id=v.get("worksite")).first() if v.get("worksite") else None
        si = ShiftInstance.objects.filter(id=v.get("shift_instance")).first() if v.get("shift_instance") else None
        ev = add_check_in(
            employee=emp, ts=v["ts"], lat=v.get("lat"), lng=v.get("lng"), accuracy_m=v.get("accuracy_m"),
            shift_instance=si, source=v.get("source", "web"), worksite=ws, raw=request.data
        )
        return Response(AttendanceEventSerializer(ev).data, status=status.HTTP_201_CREATED)



# --- Check Out ---
@extend_schema_view(
    post=extend_schema(
        tags=["Attendance"],
        summary="Check out",
        request=AttendanceCheckSerializer,
        responses={
            200: OpenApiResponse(AttendanceEventSerializer, description="Cập nhật sự kiện check-out"),
            **std_errors(),
        },
    )
)
class CheckOutView(APIView):
    def post(self, request):
        ser = AttendanceCheckSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        v = ser.validated_data
        emp = Employee.objects.get(id=v["employee"])
        ws = Worksite.objects.filter(id=v.get("worksite")).first() if v.get("worksite") else None
        si = ShiftInstance.objects.filter(id=v.get("shift_instance")).first() if v.get("shift_instance") else None
        ev = add_check_out(
            employee=emp, ts=v["ts"], lat=v.get("lat"), lng=v.get("lng"), accuracy_m=v.get("accuracy_m"),
            shift_instance=si, source=v.get("source", "web"), worksite=ws, raw=request.data
        )
        return Response(AttendanceEventSerializer(ev).data)



# --- Summary by day ---
@extend_schema_view(
    get=extend_schema(
        tags=["Attendance"],
        summary="Attendance summary theo ngày",
        parameters=[
            q_int("employee", "Employee ID"),
            q_date("date_from", "Từ ngày (YYYY-MM-DD)"),
            q_date("date_to", "Đến ngày (YYYY-MM-DD)"),
        ],
        responses=OpenApiResponse(AttendanceSummarySerializer(many=True), description="Danh sách summary"),
    )
)
class AttendanceSummaryView(APIView):
    def get(self, request):
        emp = request.query_params.get("employee")
        date_from = request.query_params.get("date_from")
        date_to = request.query_params.get("date_to")
        qs = AttendanceSummary.objects.all()
        if emp: qs = qs.filter(employee_id=emp)
        if date_from: qs = qs.filter(date__gte=date_from)
        if date_to: qs = qs.filter(date__lte=date_to)
        return Response(AttendanceSummarySerializer(qs, many=True).data)
