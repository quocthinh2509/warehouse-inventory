# inventory/v1/api/serializers.py
from django.db import transaction
from django.db.models import Sum
from rest_framework import serializers

from inventory.models import (
    Product, Warehouse, Item, Inventory, Move,
    StockOrder, StockOrderLine,
)


# ---------- Base serializers ----------
class WarehouseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Warehouse
        fields = ["id", "code", "name"]


class ProductSerializer(serializers.ModelSerializer):
    # Tổng tồn (gộp mọi kho) để tiện hiển thị
    total_quantity = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = ["id", "sku", "name", "code4", "total_quantity"]

    def get_total_quantity(self, obj):
        agg = Inventory.objects.filter(product=obj).aggregate(t=Sum("qty")).get("t")
        return agg or 0


class ItemSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    product_id = serializers.PrimaryKeyRelatedField(
        queryset=Product.objects.all(), source="product", write_only=True, required=False
    )
    warehouse = WarehouseSerializer(read_only=True)
    warehouse_id = serializers.PrimaryKeyRelatedField(
        queryset=Warehouse.objects.all(), source="warehouse", write_only=True, required=False, allow_null=True
    )

    class Meta:
        model = Item
        fields = [
            "id", "barcode_text", "product", "product_id",
            "warehouse", "warehouse_id",
            "status", "import_date", "created_at",
        ]
        read_only_fields = ["barcode_text", "created_at"]


class InventorySerializer(serializers.ModelSerializer):
    product = ProductSerializer()
    warehouse = WarehouseSerializer()

    class Meta:
        model = Inventory
        fields = ["product", "warehouse", "qty"]


class MoveSerializer(serializers.ModelSerializer):
    item = ItemSerializer(read_only=True)
    item_id = serializers.PrimaryKeyRelatedField(
        queryset=Item.objects.all(), source="item", write_only=True, required=False, allow_null=True
    )
    product = ProductSerializer(read_only=True)
    product_id = serializers.PrimaryKeyRelatedField(
        queryset=Product.objects.all(), source="product", write_only=True, required=False, allow_null=True
    )
    from_wh = WarehouseSerializer(read_only=True)
    from_wh_id = serializers.PrimaryKeyRelatedField(
        queryset=Warehouse.objects.all(), source="from_wh", write_only=True, required=False, allow_null=True
    )
    to_wh = WarehouseSerializer(read_only=True)
    to_wh_id = serializers.PrimaryKeyRelatedField(
        queryset=Warehouse.objects.all(), source="to_wh", write_only=True, required=False, allow_null=True
    )

    class Meta:
        model = Move
        fields = [
            "id", "created_at", "action",
            "item", "item_id",
            "product", "product_id", "quantity",
            "from_wh", "from_wh_id",
            "to_wh", "to_wh_id",
            "type_action", "note", "tag", "batch_id",
            "duration_seconds",
        ]
        read_only_fields = ["id", "created_at"]


# ---------- Stock Order ----------
class StockOrderLineSerializer(serializers.ModelSerializer):
    """
    Một dòng đơn: CHỌN 1 TRONG 2
    - item (có barcode)        -> qty ngầm = 1
    - product + quantity (bulk)
    Hỗ trợ thêm 'sku' (write-only) để tạo theo mã SKU (map -> product).
    """
    # Cho phép truyền sku thay cho product_id khi POST nested
    sku = serializers.CharField(write_only=True, required=False, allow_blank=False)

    # order có thể lấy từ context khi POST nested
    order = serializers.PrimaryKeyRelatedField(
        queryset=StockOrder.objects.all(), required=False, write_only=True
    )

    class Meta:
        model = StockOrderLine
        fields = ["id", "order", "item", "product", "quantity", "note", "sku"]
        read_only_fields = ["id"]

    def validate(self, attrs):
        item = attrs.get("item")
        product = attrs.get("product")
        quantity = attrs.get("quantity")
        sku = attrs.get("sku")

        # Map sku -> product nếu có sku
        if sku and not product:
            prod = Product.objects.filter(sku=sku).first()
            if not prod:
                prod = Product.objects.create(sku=sku, name=sku)
            attrs["product"] = prod

        # Kiểm tra hợp lệ item vs bulk
        item = attrs.get("item")
        product = attrs.get("product")
        quantity = attrs.get("quantity")

        if item and (product or quantity):
            raise serializers.ValidationError("Một dòng chỉ được chọn Item hoặc Product+Quantity.")
        if not item and not (product and quantity):
            raise serializers.ValidationError("Dòng thiếu dữ liệu: cần Item hoặc Product+Quantity.")
        if quantity is not None and quantity <= 0:
            raise serializers.ValidationError("Quantity phải > 0.")
        return attrs

    def create(self, validated):
        order = validated.get("order") or self.context.get("order")
        if not order:
            raise serializers.ValidationError("Thiếu 'order' khi tạo StockOrderLine.")
        if order.is_confirmed:
            raise serializers.ValidationError("Đơn đã xác nhận. Không thể thêm dòng.")
        return super().create(validated)


class StockOrderSerializer(serializers.ModelSerializer):
    """
    StockOrder + nested lines (tuỳ chọn):
    - Khi tạo mới: có thể gửi kèm 'lines' để tạo dòng cùng lúc.
    - Khi đọc: luôn trả về 'lines'.
    """
    created_by = serializers.HiddenField(default=serializers.CurrentUserDefault())
    lines = StockOrderLineSerializer(many=True, required=False, read_only=False)

    class Meta:
        model = StockOrder
        fields = [
            "id",
            "order_type", "source",
            "reference", "external_id", "note",
            "created_by", "created_at",
            "confirmed_at", "is_confirmed",
            "from_wh", "to_wh",
            "lines",
        ]
        read_only_fields = ["id", "created_at", "confirmed_at", "is_confirmed"]

    def validate(self, attrs):
        order_type = attrs.get("order_type") or getattr(self.instance, "order_type", None)
        from_wh    = attrs.get("from_wh", getattr(self.instance, "from_wh", None))
        to_wh      = attrs.get("to_wh",   getattr(self.instance, "to_wh", None))
        if order_type == "IN" and not to_wh:
            raise serializers.ValidationError("Đơn IN cần to_wh.")
        if order_type == "OUT" and not from_wh:
            raise serializers.ValidationError("Đơn OUT cần from_wh.")
        return attrs

    @transaction.atomic
    def create(self, validated_data):
        lines_data = validated_data.pop("lines", [])
        order = super().create(validated_data)

        if lines_data:
            # Đẩy 'order' vào từng line
            for ln in lines_data:
                ln["order"] = order
            lser = StockOrderLineSerializer(data=lines_data, many=True, context={"order": order})
            lser.is_valid(raise_exception=True)
            lser.save()
        return order

    @transaction.atomic
    def update(self, instance, validated_data):
        if instance.is_confirmed:
            for k in ["order_type", "from_wh", "to_wh"]:
                if k in validated_data:
                    raise serializers.ValidationError(f"Đơn đã xác nhận. Không thể sửa '{k}'.")
        return super().update(instance, validated_data)
