# inventory/v1/api/views.py
from datetime import datetime, timedelta
from collections import defaultdict

from django.db import transaction, IntegrityError
from django.db.models import Q, Sum, Count, F, IntegerField, CharField, Case, When, Value
from django.utils import timezone
from django.core.exceptions import ValidationError

from rest_framework import viewsets, status, filters
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny
from django_filters.rest_framework import DjangoFilterBackend

from inventory.models import (
    Product, Warehouse, Item, Inventory, Move,
    StockOrder, StockOrderLine,
)
from .serializers import (
    ProductSerializer, WarehouseSerializer, ItemSerializer,
    InventorySerializer, MoveSerializer,
    StockOrderSerializer, StockOrderLineSerializer,
)


# ---------- CRUD cơ bản ----------
class WarehouseViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Warehouse.objects.all().order_by("code")
    serializer_class = WarehouseSerializer
    permission_classes = [AllowAny]


class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all().order_by("sku")
    serializer_class = ProductSerializer
    permission_classes = [AllowAny]

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["sku", "name", "code4"]
    ordering_fields = ["id", "sku", "name"]
    ordering = ["id"]

    def get_queryset(self):
        qs = super().get_queryset()
        q = (self.request.query_params.get("q") or "").strip()
        if q:
            qs = qs.filter(Q(sku__icontains=q) | Q(name__icontains=q) | Q(code4__icontains=q))
        return qs


class ItemViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Item.objects.select_related("product", "warehouse").order_by("-created_at")
    serializer_class = ItemSerializer
    permission_classes = [AllowAny]

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["barcode_text", "product__sku", "product__name", "product__code4"]
    ordering_fields = ["id", "created_at"]
    ordering = ["-created_at"]

    def get_queryset(self):
        qs = super().get_queryset()
        q = (self.request.query_params.get("q") or "").strip()
        wh = self.request.query_params.get("wh") or ""
        status_ = (self.request.query_params.get("status") or "").strip()
        date_from = (self.request.query_params.get("date_from") or "").strip()
        date_to = (self.request.query_params.get("date_to") or "").strip()

        if q:
            qs = qs.filter(
                Q(barcode_text__icontains=q) |
                Q(product__sku__icontains=q) |
                Q(product__name__icontains=q) |
                Q(product__code4__icontains=q)
            )
        if wh:
            qs = qs.filter(warehouse_id=wh)
        if status_:
            qs = qs.filter(status=status_)
        if date_from:
            try:
                qs = qs.filter(created_at__date__gte=datetime.strptime(date_from, "%Y-%m-%d").date())
            except ValueError:
                pass
        if date_to:
            try:
                qs = qs.filter(created_at__date__lte=datetime.strptime(date_to, "%Y-%m-%d").date())
            except ValueError:
                pass
        return qs


# ---------- Inventory tổng hợp ----------
class InventoryView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        wh = request.GET.get("wh") or ""
        q = (request.GET.get("q") or "").strip()

        inv_qs = Inventory.objects.select_related("warehouse", "product")

        if wh:
            inv_qs = inv_qs.filter(warehouse_id=wh)
        if q:
            inv_qs = inv_qs.filter(
                Q(product__sku__icontains=q) | Q(product__name__icontains=q) | Q(product__code4__icontains=q)
            )

        rows = (
            inv_qs.values("warehouse__code", "product__sku", "product__name")
            .annotate(qty=Sum("qty"))
            .order_by("warehouse__code", "product__sku")
        )

        return Response({
            "results": list(rows),
            "total_records": rows.count(),
            "total_skus": inv_qs.values("product__sku").distinct().count(),
            "total_qty": sum(r["qty"] or 0 for r in rows),
        })


# ---------- Barcode lookup ----------
class BarcodeCheckView(APIView):
    permission_classes = [AllowAny]

    def _item_payload(self, item):
        return {
            "id": item.id,
            "barcode": item.barcode_text,
            "status": item.status,
            "import_date": item.import_date.isoformat() if item.import_date else None,
            "created_at": item.created_at.isoformat() if item.created_at else None,
            "product": {
                "id": item.product.id, "sku": item.product.sku,
                "name": item.product.name, "code4": item.product.code4,
            } if item.product else None,
            "warehouse": {
                "id": item.warehouse.id, "code": item.warehouse.code, "name": item.warehouse.name,
            } if item.warehouse else None,
        }

    def _move_payload(self, mv):
        return {
            "id": mv.id, "action": mv.action, "type_action": mv.type_action,
            "from_wh": mv.from_wh.code if mv.from_wh else None,
            "to_wh": mv.to_wh.code if mv.to_wh else None,
            "tag": mv.tag, "note": mv.note,
            "created_at": mv.created_at.isoformat() if mv.created_at else None,
        }

    def _find_barcode(self, request):
        return (request.query_params.get("barcode")
                or request.data.get("barcode")
                or request.data.get("code")
                or "").strip()

    def get(self, request):
        code = self._find_barcode(request)
        if not code:
            return Response({"detail": "Thiếu barcode."}, status=400)
        try:
            item = Item.objects.select_related("product", "warehouse").get(barcode_text=code)
        except Item.DoesNotExist:
            return Response({"detail": f"Không tìm thấy {code}"}, status=404)

        moves = item.moves.select_related("from_wh", "to_wh").order_by("-created_at")
        return Response({
            "item": self._item_payload(item),
            "moves": [self._move_payload(m) for m in moves]
        })

    def post(self, request):
        return self.get(request)


# ---------- Stock Orders ----------
class StockOrderViewSet(viewsets.ModelViewSet):
    """
    /api/v1/orders/                      GET, POST
    /api/v1/orders/{id}/                 GET, PATCH, DELETE
    /api/v1/orders/{id}/confirm/         POST
    /api/v1/orders/{id}/add-line/        POST
    /api/v1/orders/upsert-confirm/       POST   (1 request: tạo/cập nhật + xác nhận)
    """
    queryset = (
        StockOrder.objects
        .select_related("from_wh", "to_wh", "created_by")
        .prefetch_related("lines__item", "lines__product")
        .order_by("-id")
    )
    serializer_class = StockOrderSerializer
    permission_classes = [AllowAny]

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["order_type", "source", "is_confirmed", "from_wh", "to_wh", "external_id"]
    search_fields = ["reference", "note"]
    ordering_fields = ["id", "created_at", "confirmed_at"]
    ordering = ["-id"]

    def create(self, request, *args, **kwargs):
        # idempotent nhẹ theo external_id
        external_id = (request.data.get("external_id") or "").strip() or None
        if external_id:
            existed = StockOrder.objects.filter(external_id=external_id).first()
            if existed:
                ser = self.get_serializer(existed)
                return Response({"detail": "EXISTS", **ser.data}, status=status.HTTP_200_OK)
        return super().create(request, *args, **kwargs)

    @action(detail=True, methods=["post"])
    def confirm(self, request, pk=None):
        order = self.get_object()
        if order.is_confirmed:
            return Response({"detail": "Đơn đã xác nhận."}, status=200)
        batch_id = (request.data or {}).get("batch_id") or f"ORDER-{order.id}"
        with transaction.atomic():
            order.confirm(batch_id=batch_id)
        return Response(self.get_serializer(order).data, status=200)

    @action(detail=True, methods=["post"], url_path="add-line")
    def add_line(self, request, pk=None):
        order = self.get_object()
        if order.is_confirmed:
            return Response({"detail": "Đơn đã xác nhận. Không thể thêm dòng."}, status=400)

        payload = dict(request.data or {})
        # Hỗ trợ sku -> product
        if "sku" in payload and not payload.get("product"):
            sku = str(payload.get("sku") or "").strip()
            if not sku:
                return Response({"detail": "Thiếu sku."}, status=400)
            prod = Product.objects.filter(sku=sku).first() or Product.objects.create(sku=sku, name=sku)
            payload["product"] = prod.id
            payload.pop("sku", None)

        payload["order"] = order.id
        ser = StockOrderLineSerializer(data=payload, context={"order": order})
        ser.is_valid(raise_exception=True)
        ser.save()
        return Response(StockOrderSerializer(order).data, status=201)

    @action(detail=False, methods=["post"], url_path="upsert-confirm")
    def upsert_confirm(self, request):
        """
        1 lần gọi: tạo/cập nhật + xác nhận đơn.
        Body:
        {
          "id": 12?, "external_id": "EXT-1"?, "order_type": "IN|OUT", "source": "...",
          "reference": "...", "note": "...", "from_wh": 1?, "to_wh": 2?,
          "replace_lines": true?, "batch_id": "...",
          "lines": [
            {"item": 104, "note":"..."} |
            {"product": 5, "quantity": 10, "note":"..."} |
            {"sku": "SKU001", "quantity": 3, "note":"..."}
          ]
        }
        """
        data = dict(request.data or {})
        replace_lines = bool(data.pop("replace_lines", False))
        batch_id = (data.pop("batch_id", "") or "").strip()

        order_id    = data.get("id")
        external_id = (data.get("external_id") or "").strip() or None

        with transaction.atomic():
            # Resolve order
            order = None
            if order_id:
                order = StockOrder.objects.select_for_update().filter(id=order_id).first()
                if not order:
                    return Response({"detail": "Không tìm thấy order theo id."}, status=404)
            elif external_id:
                order = StockOrder.objects.select_for_update().filter(external_id=external_id).first()

            lines_payload = data.pop("lines", None)

            if not order:
                # Validate bắt buộc cho đơn mới
                ot = (data.get("order_type") or "").upper()
                if ot not in {"IN", "OUT"}:
                    return Response({"detail": "order_type phải là IN/OUT."}, status=400)
                if ot == "IN" and not data.get("to_wh"):
                    return Response({"detail": "Đơn IN cần to_wh."}, status=400)
                if ot == "OUT" and not data.get("from_wh"):
                    return Response({"detail": "Đơn OUT cần from_wh."}, status=400)

                ser = StockOrderSerializer(data=data, context={"request": request})
                ser.is_valid(raise_exception=True)
                order = ser.save()
            else:
                if not order.is_confirmed:
                    ser = StockOrderSerializer(order, data=data, partial=True, context={"request": request})
                    ser.is_valid(raise_exception=True)
                    ser.save()

            # Xử lý lines nếu có và đơn chưa confirm
            if lines_payload and not order.is_confirmed:
                if replace_lines:
                    order.lines.all().delete()

                normalized = []
                for ln in lines_payload:
                    ln = dict(ln or {})
                    # Cho phép dùng sku
                    if "sku" in ln and not ln.get("product"):
                        sku = str(ln.get("sku") or "").strip()
                        if not sku:
                            return Response({"detail": "Thiếu sku trong lines."}, status=400)
                        prod = Product.objects.filter(sku=sku).first() or Product.objects.create(sku=sku, name=sku)
                        ln["product"] = prod.id
                        ln.pop("sku", None)
                    ln["order"] = order.id
                    normalized.append(ln)

                lser = StockOrderLineSerializer(data=normalized, many=True, context={"order": order})
                lser.is_valid(raise_exception=True)
                lser.save()

            # Confirm luôn
            if not order.is_confirmed:
                order.confirm(batch_id=batch_id or f"ORDER-{order.id}")

        return Response(StockOrderSerializer(order).data, status=200)


class StockOrderLineViewSet(viewsets.ModelViewSet):
    queryset = StockOrderLine.objects.select_related("order", "item", "product").order_by("-id")
    serializer_class = StockOrderLineSerializer
    permission_classes = [AllowAny]

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["order", "product", "item"]
    search_fields = ["note", "product__sku"]
    ordering_fields = ["id", "order"]
    ordering = ["-id"]

    def perform_destroy(self, instance):
        if instance.order and instance.order.is_confirmed:
            raise ValidationError("Đơn đã xác nhận. Không thể xoá dòng.")
        return super().perform_destroy(instance)


# ---------- Bulk import nhiều đơn (SKU-based) ----------
class BulkImportOrdersView(APIView):
    """
    POST /api/v1/bulk/import-orders
    Body:
    {
      "orders": [
        {
          "external_id": "EXT-1",
          "order_type": "OUT" | "IN",
          "warehouse_code": "WH1" | null,
          "warehouse_id": 1 | null,
          "reference": "SO-1",
          "note": "...",
          "lines": [ {"sku": "A", "qty": 2}, {"sku": "B", "qty": 3} ]
        },
        ...
      ]
    }
    - Tự tạo Warehouse/Product nếu chưa có.
    - Nếu external_id đã tồn tại → bỏ qua tạo mới, trả về status=skipped.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        payload = request.data if isinstance(request.data, dict) else {}
        orders = payload.get("orders") or []
        if not isinstance(orders, list) or not orders:
            return Response({"detail": "Thiếu orders."}, status=400)

        results = []
        for od in orders:
            try:
                wh_id = od.get("warehouse_id")
                wh_code = od.get("warehouse_code")
                reference = (od.get("reference") or "").strip()
                external_id = (od.get("external_id") or "").strip() or None
                note = (od.get("note") or "").strip()
                order_type = (od.get("order_type") or "OUT").upper()
                lines = od.get("lines") or []

                # Resolve warehouse (auto-create theo code)
                wh = None
                if wh_id:
                    wh = Warehouse.objects.filter(id=wh_id).first()
                if not wh and wh_code:
                    wh = Warehouse.objects.filter(code=wh_code).first()
                    if not wh:
                        wh = Warehouse.objects.create(code=wh_code, name=wh_code)
                if not wh:
                    raise ValueError("Kho không hợp lệ (cần warehouse_code hoặc warehouse_id).")

                if not isinstance(lines, list) or not lines:
                    raise ValueError("Thiếu lines.")

                skus = [str((ln.get("sku") or "").strip()) for ln in lines]
                qtys = []
                for ln in lines:
                    try:
                        q = int(ln.get("qty") or ln.get("quantity") or 0)
                    except Exception:
                        q = 0
                    qtys.append(q)
                if any((not s) for s in skus) or any(q <= 0 for q in qtys):
                    raise ValueError("Mỗi dòng cần sku và qty>0.")

                # Load/create products
                products = {p.sku: p for p in Product.objects.filter(sku__in=skus)}
                for s in skus:
                    if s not in products:
                        products[s] = Product.objects.create(sku=s, name=s)

                # Gộp theo sku
                grouped = defaultdict(int)
                for s, q in zip(skus, qtys):
                    grouped[s] += int(q)

                if external_id:
                    existed = StockOrder.objects.filter(external_id=external_id).first()
                    if existed:
                        results.append({"external_id": external_id, "order_id": existed.id, "status": "skipped"})
                        continue

                with transaction.atomic():
                    order = StockOrder.objects.create(
                        order_type=order_type,
                        source="API",
                        reference=reference,
                        external_id=external_id,
                        note=note,
                        from_wh=wh if order_type == "OUT" else None,
                        to_wh=wh if order_type == "IN" else None,
                    )
                    for sku, total_qty in grouped.items():
                        StockOrderLine.objects.create(
                            order=order, product=products[sku], quantity=total_qty, note=note
                        )
                    order.confirm(batch_id=f"API-{timezone.localtime().strftime('%Y%m%d-%H%M%S')}")

                results.append({"external_id": external_id, "order_id": order.id, "status": "created"})
            except Exception as e:
                results.append({"external_id": od.get("external_id"), "error": str(e), "status": "error"})

        return Response({"results": results})
class CreateBarcodesView(APIView):
    """
    POST /api/v1/barcodes/create
    Body:
    {
      "lines": [
        {"sku": "SKU001", "name": "Áo thun trắng", "qty": 3, "import_date": "2025-09-03"},
        {"sku": "SKU002", "qty": 2},
        {"sku": "SKU003", "qty": 1, "import_date": "03/09/2025"}  # hỗ trợ dd/MM/yyyy
      ]
    }
    -> Tạo Product (nếu thiếu) và tạo Item (barcode tự sinh trong model).
    """
    permission_classes = [AllowAny]

    def _parse_import_date(self, s):
        if not s:
            return None
        s = str(s).strip()
        for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
            try:
                return datetime.strptime(s, fmt).date()
            except Exception:
                pass
        raise ValidationError(f"Ngày không hợp lệ: {s} (hỗ trợ YYYY-MM-DD hoặc dd/MM/yyyy)")

    @transaction.atomic
    def post(self, request):
        payload = request.data if isinstance(request.data, dict) else {}
        lines = payload.get("lines") or []
        if not isinstance(lines, list) or not lines:
            return Response({"detail": "Thiếu lines."}, status=400)

        created_items, total = [], 0

        for row in lines:
            if not isinstance(row, dict):
                continue
            sku = (row.get("sku") or "").strip()
            if not sku:
                return Response({"detail": "Mỗi dòng cần 'sku'."}, status=400)
            try:
                qty = int(row.get("qty") or 0)
            except Exception:
                qty = 0
            if qty <= 0:
                return Response({"detail": f"SKU {sku}: qty phải > 0."}, status=400)

            name = (row.get("name") or "").strip() or sku
            import_date = self._parse_import_date(row.get("import_date"))

            # Product
            product, created_prod = Product.objects.get_or_create(sku=sku, defaults={"name": name})
            if not created_prod and name and product.name != name:
                product.name = name
                product.save(update_fields=["name"])

            # Items
            for _ in range(qty):
                it = Item.objects.create(product=product, import_date=import_date)
                created_items.append({
                    "id": it.id,
                    "barcode": it.barcode_text,
                    "sku": product.sku,
                    "product_id": product.id,
                    "import_date": it.import_date.isoformat(),
                })
                total += 1

        return Response({"detail": "OK", "total_created": total, "items": created_items}, status=201)


class ScanOnceView(APIView):
    """
    POST /api/v1/scan/once
    Body:
    {
      "barcode": "1001122500012",
      "action": "IN" | "OUT",
      "wh_id": 1,              # IN: bắt buộc; OUT: optional (nếu không gửi sẽ lấy item.warehouse)
      "type_action": "SCAN"?,  # optional
      "tag": 1?                # optional
    }
    """
    permission_classes = [AllowAny]

    @transaction.atomic
    def post(self, request):
        barcode = (request.data.get("barcode") or "").strip()
        action = (request.data.get("action") or "").strip().upper()
        wh_id = request.data.get("wh_id")
        type_action = (request.data.get("type_action") or "SCAN").strip()
        try:
            tag = int(request.data.get("tag") or 1)
        except Exception:
            tag = 1

        if not barcode:
            return Response({"detail": "Thiếu barcode."}, status=400)
        if action not in {"IN", "OUT"}:
            return Response({"detail": "action phải là IN/OUT."}, status=400)

        # Lấy item (khoá dòng để tránh race)
        try:
            item = (
                Item.objects
                .select_for_update()
                .select_related("product", "warehouse")
                .get(barcode_text=barcode)
            )
        except Item.DoesNotExist:
            return Response({"detail": f"Không tìm thấy {barcode}"}, status=404)

        wh = Warehouse.objects.filter(id=wh_id).first() if wh_id else None

        if action == "IN":
            if not wh:
                return Response({"detail": "IN cần wh_id."}, status=400)
            if item.warehouse:
                return Response({"detail": f"{barcode} đang ở {item.warehouse.code}."}, status=400)

            mv = Move.objects.create(
                item=item, action="IN", to_wh=wh,
                type_action=type_action, tag=tag, note="IN (scan v1)"
            )
            # cập nhật tồn kho & item
            item.warehouse = wh
            item.status = "in_stock"
            item.save(update_fields=["warehouse", "status"])
            Inventory.adjust(item.product, wh, +1)
            message = f"IN {barcode} → {wh.code}"

        else:  # OUT
            if not item.warehouse and not wh:
                return Response({"detail": f"{barcode} đã OUT trước đó."}, status=400)

            base_wh = wh or item.warehouse
            if wh and item.warehouse and item.warehouse != wh:
                return Response({"detail": f"{barcode} đang ở {item.warehouse.code}, khác kho gửi ({wh.code})."}, status=400)

            mv = Move.objects.create(
                item=item, action="OUT", from_wh=base_wh,
                type_action=type_action, tag=tag, note="OUT (scan v1)"
            )
            Inventory.adjust(item.product, base_wh, -1)
            item.warehouse = None
            item.status = "shipped"
            item.save(update_fields=["warehouse", "status"])
            message = f"OUT {barcode}"

        return Response({
            "detail": "OK",
            "message": message,
            "move": {
                "id": mv.id,
                "action": mv.action,
                "from_wh": mv.from_wh.code if mv.from_wh else None,
                "to_wh": mv.to_wh.code if mv.to_wh else None,
                "type_action": mv.type_action,
                "tag": mv.tag,
                "created_at": mv.created_at.isoformat(),
            },
            "item": {
                "id": item.id,
                "barcode": item.barcode_text,
                "status": item.status,
                "warehouse": item.warehouse.code if item.warehouse else None,
                "product": {"id": item.product.id, "sku": item.product.sku, "name": item.product.name},
            }
        }, status=200)