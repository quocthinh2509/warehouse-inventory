# inventory/v1/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from inventory.v1.api.views import (
    WarehouseViewSet, ProductViewSet, ItemViewSet,
    InventoryView, BarcodeCheckView,
    StockOrderViewSet, StockOrderLineViewSet,
    BulkImportOrdersView,
)

router = DefaultRouter()
router.register(r"warehouses", WarehouseViewSet, basename="v1-warehouses")
router.register(r"products",   ProductViewSet,   basename="v1-products")
router.register(r"items",      ItemViewSet,      basename="v1-items")
router.register(r"orders",     StockOrderViewSet, basename="v1-orders")
router.register(r"order-lines", StockOrderLineViewSet, basename="v1-order-lines")

urlpatterns = [
    path("", include(router.urls)),

    # Inventory tổng hợp
    path("inventory/", InventoryView.as_view(), name="v1-inventory"),

    # Barcode lookup (item + move history)
    path("barcode/check", BarcodeCheckView.as_view(), name="v1-barcode-check"),

    # Bulk import nhiều đơn (tự confirm)
    path("bulk/import-orders", BulkImportOrdersView.as_view(), name="v1-bulk-import-orders"),
]
